# 🚀 Camina hacia el Futuro

**Plataforma de orientación vocacional para jóvenes recién graduados (14–35 años)**  
*¿No sabes qué estudiar o dónde trabajar? Este test te ayuda a descubrirlo.*

---

## 🎯 Visión y objetivo

Camina hacia el Futuro es una aplicación web estática que guía a jóvenes sin rumbo a través de un cuestionario vocacional de 50 preguntas, detecta su área de mayor aptitud y les recomienda carreras universitarias o puestos de trabajo en instituciones/empresas de su ciudad.

---

## ✅ Funcionalidades implementadas

### 🔐 Autenticación
- Registro con: nombre, correo, contraseña (mín. 8 chars), ciudad, edad (14–35), teléfono (opcional)
- Inicio de sesión con validación en tiempo real
- Barra de fuerza de contraseña visual
- Visibilidad de contraseña (toggle)
- Redirección automática si la sesión ya está activa
- Hash de contraseña (simulado en frontend con `simpleHash()`)
- Logout global con confirmación

### 🗺️ Flujo de navegación
- **`index.html`** → Login/Registro (tabs)
- **`index.html`** → Login/Registro (raíz del proyecto)
- **`html/eleccion.html`** → Elección de tipo de test: Estudio o Trabajo
- **`html/preguntas-generales.html`** → 20 preguntas generales con barra de progreso y modal de cancelación
- **`html/cuestionario-final.html`** → 30 preguntas específicas del área detectada
- **`html/resultados.html`** → Resultados completos con puntaje, veredicto, ubicaciones y PDF
- **`perfil.html`** → Perfil del usuario con edición de datos y cambio de contraseña
- **`historial.html`** → Historial de todos los tests completados con estadísticas
- **`404.html`** → Página de error / no encontrado

### 📋 Sistema de tests
| Sección | Preguntas | Tipo |
|---------|-----------|------|
| Generales Estudio | 20 | Opción múltiple con pesos por área |
| Generales Trabajo | 20 | Opción múltiple con pesos por área |
| Final Estudio (áreas 1–10) | 30 c/u | Opción múltiple |
| Final Trabajo (áreas 1–10) | 30 c/u | Mixto: opción múltiple + texto libre |

**Total: 10 cuestionarios de Estudio + 10 cuestionarios de Trabajo = 300 preguntas finales únicas**

### 🧠 Algoritmo vocacional
1. Cada opción de las preguntas generales lleva un array `areas: [id1, id2, ...]`
2. Las respuestas acumulan puntos por área (`areaPuntajes`)
3. El área con mayor puntaje selecciona el cuestionario final de 30 preguntas
4. El puntaje final = (respuestas correctas / total) × 100
5. **Califica si puntaje ≥ 60%**
6. Las ubicaciones (universidades/empresas) se filtran por ciudad del usuario

### 👤 Perfil de usuario
- Ver datos personales
- Editar: nombre, ciudad, edad, teléfono (con validación en tiempo real)
- Cambio de contraseña con validación de contraseña actual
- Indicador de fuerza de contraseña nueva
- Estadísticas de actividad (tests realizados, último puntaje)
- Acciones rápidas: ir a nuevo test de Estudio o Trabajo
- Borrar datos de test con modal de confirmación

### 📋 Historial
- Lista de todos los tests completados ordenados por fecha
- Filtros: Todos / Estudio / Trabajo
- Estadísticas: total, calificaron, promedio, mejor puntaje
- Banner de test en progreso con botón de continuación
- **Acordeón de detalle** por entrada: área vocacional, puntaje, nivel de desempeño, fecha/hora, carrera/puesto, acciones rápidas
- Se guarda automáticamente al completar cada test

### 📄 PDF de resultados
- Generado completamente en el cliente con jsPDF 2.5
- Incluye: encabezado, datos del usuario, resultado principal, universidades/empresas, opciones similares, detalle de todas las respuestas
- Fallback a `.txt` si las librerías no están disponibles

### 🎨 Diseño
- **Paleta pastel:** lavanda `#F4F0FF` (bg), violeta `#7C5CBF` (primary), azul `#5BA8F5` (Estudio), verde `#5DBF8A` (Trabajo)
- **Modo oscuro** completo con pasteles apagados (nunca negro puro)
- **Fuente:** Inter (Google Fonts)
- **Mobile-first:** responsive con breakpoints en 640px y 380px
- **Touch targets ≥ 44 px** en páginas de quiz + `env(safe-area-inset-bottom)` para notch iOS
- Animaciones: `fadeInUp`, loading con tres puntos animados
- ARIA completo: `role`, `aria-label`, `aria-live`, `aria-pressed`, `aria-expanded`

### 💾 Historial con respuestas completas
- Cada entrada del historial **guarda ahora el `detalle[]` completo** de las respuestas del cuestionario final
- En el acordeón de cada entrada se muestran: estadísticas (correctas / incorrectas / libres), y un sub-acordeón "Ver las N respuestas" con cada pregunta, respuesta del usuario, respuesta correcta y aporte al puntaje
- Tests anteriores a la actualización muestran un aviso de que las respuestas no están disponibles
- Nuevos campos guardados en historial: `areaIcon`, `areaPuntajes`, `totalPreguntas`, `correctas`, `incorrectas`, `textosLibres`

### 📈 Gráfica de progreso (Chart.js)
- `historial.html` muestra una **gráfica de líneas** con la evolución del puntaje a lo largo del tiempo (visible cuando hay ≥ 2 tests)
- Dos series de datos: Estudio (azul) y Trabajo (verde), con área rellena semitransparente
- **Línea de mínimo al 60%** dibujada con plugin inline, marcada con etiqueta "mínimo 60%"
- Tooltips con estado de aprobación (✅ / ⚠️) por punto
- Se re-renderiza automáticamente al cambiar filtros (siempre muestra el historial completo)
- Responsive: altura 240px en desktop, 200px en móvil

---

## 📁 Estructura de archivos

```
camina-hacia-el-futuro/
├── index.html                  # Login / Registro (punto de entrada)
├── favicon.svg                 # Favicon del proyecto
├── html/                       # Todas las páginas de la app (requieren sesión)
│   ├── eleccion.html           # Selección de tipo de test
│   ├── preguntas-generales.html # 20 preguntas generales
│   ├── cuestionario-final.html # 30 preguntas finales
│   ├── resultados.html         # Resultados, PDF
│   ├── perfil.html             # Perfil de usuario
│   ├── historial.html          # Historial de tests + Chart.js
│   └── 404.html                # Página de error
├── .env.example                # Variables de entorno para producción
├── css/
│   ├── variables.css           # Sistema de diseño: tokens CSS, modo oscuro
│   ├── base.css                # Reset, headings, utilidades
│   └── components.css          # Botones, cards, forms, quiz options, loading, etc.
├── js/
│   ├── data.js                 # Base de datos local: 10 áreas, 40 preguntas generales,
│   │                           # 300 preguntas finales, 16 universidades, 18 empresas
│   ├── auth.js                 # Módulo de autenticación (IIFE → window.Auth)
│   ├── quiz.js                 # Motor del quiz (IIFE → window.Quiz)
│   └── app.js                  # Utilidades globales: Theme, Loading, Nav, PDFGen, Toast
└── docs/
    ├── guia-tecnica.md         # Arquitectura, algoritmo, localStorage schema
    ├── guia-usuario.md         # Manual del usuario paso a paso
    ├── modelo-datos-mysql.sql  # Schema MySQL 8 completo para producción
    └── plan-migracion-backend.md # Roadmap Flask + MySQL
```

---

## 🔑 Rutas y páginas

| URL | Descripción | Protección |
|-----|-------------|------------|
| `index.html` | Login / Registro | Redirige a `html/eleccion.html` si hay sesión activa |
| `html/eleccion.html` | Elegir Estudio o Trabajo (`?flujo=estudio\|trabajo`) | Requiere sesión |
| `html/preguntas-generales.html` | Sección 1: 20 preguntas | Requiere sesión + quiz state |
| `html/cuestionario-final.html` | Sección 2: 30 preguntas | Requiere sesión + fase=final |
| `html/resultados.html` | Resultados + PDF | Requiere sesión + fase=resultados |
| `html/perfil.html` | Perfil del usuario | Requiere sesión |
| `html/historial.html` | Historial de tests + gráfica Chart.js | Requiere sesión |
| `html/404.html` | Página de error | Pública |

---

## 💾 Modelo de datos (localStorage)

| Clave | Tipo | Descripción |
|-------|------|-------------|
| `catf_users` | `object` | Usuarios indexados por correo |
| `catf_session` | `object` | Sesión activa: `{ correo, nombre, ciudad, createdAt }` |
| `catf_quiz_{correo}` | `object` | Estado completo del quiz activo del usuario |
| `catf_historial_{correo}` | `array` | Historial de tests completados |
| `catf_auth_logs` | `array` | Logs de eventos de autenticación (máx. 200) |
| `catf_theme` | `string` | `"light"` o `"dark"` |

### Estructura del estado del quiz (`catf_quiz_{correo}`)
```json
{
  "id": "quiz_1234567890",
  "flujo": "Estudio",
  "fase": "generales | final | resultados",
  "preguntasGenerales": [...],
  "respuestasGenerales": { "GE01": 2, "GE02": 0, ... },
  "areaPuntajes": { "1": 3, "2": 1, "3": 4, ... },
  "areaSeleccionada": 3,
  "cuestionarioFinal": { "titulo": "...", "preguntas": [...] },
  "respuestasFinal": { "FE3_01": 1, "FE3_02": "texto..." },
  "resultados": {
    "porcentaje": 73,
    "califica": true,
    "area": { "id": 3, "nombre": "Arte y Diseño" },
    "principal": { "nombre": "Diseño Gráfico", ... },
    "similares": [...],
    "ubicaciones": [...],
    "detalle": [...],
    "fecha": "2026-06-11T..."
  },
  "iniciado": "2026-06-11T..."
}
```

---

## 🗺️ Áreas vocacionales

| ID | Nombre | Icon |
|----|--------|------|
| 1 | Tecnología e Informática | 💻 |
| 2 | Salud y Ciencias Médicas | 🩺 |
| 3 | Arte y Diseño | 🎨 |
| 4 | Negocios y Administración | 📊 |
| 5 | Educación y Humanidades | 📚 |
| 6 | Ingeniería y Construcción | 🔧 |
| 7 | Gastronomía y Hotelería | 🍳 |
| 8 | Derecho y Ciencias Sociales | ⚖️ |
| 9 | Comunicación y Medios | 📡 |
| 10 | Ciencias Naturales | 🔬 |

---

## 🔧 Stack técnico

### Frontend (activo)
- HTML5 semántico + CSS3 (custom properties) + JavaScript ES6+ (vanilla)
- Patrón IIFE para módulos: `Auth`, `Quiz`, `Theme`, `Loading`, `Nav`, `PDFGen`, `Toast`
- jsPDF 2.5.1 (CDN) para generación de PDF client-side
- Google Fonts (Inter) + CDN jsDelivr
- localStorage como base de datos simulada

### Backend (pendiente — ver `docs/plan-migracion-backend.md`)
- Python 3.11 + Flask 3.x
- MySQL 8 (schema en `docs/modelo-datos-mysql.sql`)
- bcrypt para hashing de contraseñas
- JWT para sesiones

---

## 🚀 Cómo ejecutar localmente

No requiere servidor de backend para la versión actual.

```bash
# Opción 1: Extensión Live Server de VSCode
# Clic derecho en index.html → "Open with Live Server"

# Opción 2: Python
python -m http.server 3000
# Abrir: http://localhost:3000

# Opción 3: Node.js
npx serve .
# Abrir: http://localhost:3000
```

---

## 🌐 Despliegue

Para publicar la aplicación, usa la **pestaña Publish** de la plataforma. El proceso es automático y te proporcionará la URL pública.

---

## ⏳ Pendiente / Próximos pasos

- [ ] **Backend Flask + MySQL** — migrar auth y quiz al servidor (`docs/plan-migracion-backend.md`)
- [ ] **Tests automatizados** — pytest para backend, Playwright para E2E
- [ ] **Comparación de tests** — nueva página que compara dos entradas del historial lado a lado
- [ ] **Notificaciones mejoradas** — sistema Toast con cola, posición y duración configurables

---

## 📋 Checklist de entrega

- [x] Sistema de diseño CSS completo (variables, base, componentes)
- [x] Módulo de autenticación (`auth.js`) — register, login, logout, updateProfile, changePassword
- [x] Motor de quiz (`quiz.js`) — algoritmo de áreas, selección de cuestionario, cálculo de resultados + auto-save
- [x] Utilidades globales (`app.js`) — Theme, Loading, Nav, PDFGen, Toast
- [x] Base de datos local (`data.js`) — 10 áreas, 40 preguntas generales, 300 preguntas finales (únicas), 40 universidades, 50 empresas
- [x] `index.html` — Login/Registro con validación y strength bar
- [x] `eleccion.html` — Selección de tipo de test + **pre-selección por `?flujo=estudio|trabajo`**
- [x] `preguntas-generales.html` — 20 preguntas con progreso y modal de cancelación + **mejoras responsive móvil**
- [x] `cuestionario-final.html` — 30 preguntas mixtas con validación + **mejoras responsive móvil**
- [x] `resultados.html` — Puntaje, veredicto, ubicaciones, similares, PDF + **"Ver historial" + "Compartir resultado"**
- [x] `perfil.html` — Edición de perfil, cambio de contraseña, zona de peligro
- [x] `historial.html` — Historial con filtros, estadísticas, acordeón de detalle + **respuestas completas guardadas** + **gráfica Chart.js de progreso**
- [x] `404.html` — Página de error
- [x] `favicon.svg` — Icono del proyecto
- [x] Modo oscuro completo
- [x] Navegación al perfil en todos los headers
- [x] Auto-guardado en historial al completar test
- [x] Seed data: 40 universidades × 9 ciudades colombianas
- [x] Seed data: 50 empresas × 6 ciudades colombianas
- [x] README, .env.example, SQL schema, guías técnica y de usuario, plan de migración

---

## 👨‍💻 Desarrollado con

- **Plataforma:** Genspark AI Static Website Builder
- **Fecha de inicio:** Junio 2026
- **Tipo:** Proyecto educativo / orientación vocacional
