# Guía de Usuario — Camina hacia el Futuro

## ¿Qué es esta plataforma?

**Camina hacia el Futuro** es un cuestionario vocacional en línea que ayuda a jóvenes recién graduados a descubrir:
- **¿Qué carrera universitaria estudiar?** según sus gustos, materias favoritas y habilidades
- **¿En qué trabajo aplicar?** según sus fortalezas, personalidad y experiencia previa

---

## ¿Cómo funciona paso a paso?

### Paso 1 — Crea tu cuenta o inicia sesión
- Ingresa a la página principal
- Si es tu primera vez: haz clic en **"Crear Cuenta"** e ingresa:
  - Nombre completo
  - Correo electrónico
  - Ciudad donde vives
  - Edad
  - Teléfono (opcional)
  - Contraseña (mínimo 8 caracteres)
- Si ya tienes cuenta: haz clic en **"Iniciar Sesión"** con tu correo y contraseña

### Paso 2 — Elige entre Estudio o Trabajo
- Verás dos tarjetas: **🎓 ESTUDIO** y **💼 TRABAJO**
- Haz clic en la que más te interese
  - Si eliges **Estudio**: el test buscará la carrera universitaria ideal para ti
  - Si eliges **Trabajo**: el test encontrará el puesto de trabajo más adecuado
- Una vez elegida, se habilitará el botón **"Iniciar Test"** — dale clic para comenzar

### Paso 3 — Preguntas Generales (20 preguntas)
- Responde 20 preguntas sobre tus gustos, intereses y habilidades
- Ejemplos: *¿Qué materia disfrutabas más? ¿Qué tipo de trabajo describes como ideal?*
- **Todas las preguntas son obligatorias** — si omites alguna, el sistema te avisará con un mensaje rojo
- Al terminar las 20 preguntas, haz clic en **"Siguiente página →"**

### Paso 4 — Cuestionario Final (30 preguntas)
- El sistema detectará automáticamente tu área vocacional y te presentará un cuestionario específico
- **Para Estudio:** Preguntas de selección múltiple sobre conceptos y aptitudes del área detectada
- **Para Trabajo:** Preguntas tipo entrevista de trabajo donde debes responder con texto
- **Todas las preguntas son obligatorias**
- Al terminar, haz clic en **"Mostrar Resultados 🏆"**

### Paso 5 — Tus Resultados
Verás:
- **Tu puntaje final en porcentaje**
- **Si CALIFICASTE o no** para la carrera/trabajo sugerido
- **El nombre de la carrera o puesto recomendado**
- **Universidades o empresas en tu ciudad** donde puedes aplicar
- **El detalle completo** de cada pregunta con la respuesta correcta
- **Botón "Ver otras opciones"** para explorar carreras/trabajos similares

### Paso 6 — Descarga tu PDF
- Haz clic en **"📄 Descargar PDF"** para guardar tus resultados completos
- El PDF incluye: tu puntaje, veredicto, ubicaciones, todas las respuestas y sus correcciones

---

## Consejos para mejores resultados

- Responde con honestidad — no hay respuestas "perfectas", solo las que reflejan tu realidad
- Si no sabes algo del cuestionario final, elige la opción que más se acerque a tu pensamiento actual
- En las preguntas de texto libre (entrevista), escribe con tus propias palabras, no necesitas ser perfecto/a
- Los resultados son **orientativos** — son una guía, no una decisión definitiva

---

## Preguntas Frecuentes

**¿Puedo cambiar entre Estudio y Trabajo?**  
Sí, mientras no hayas iniciado el cuestionario. Haz clic en el botón **"← Cambiar opción"** en la parte inferior.

**¿Qué pasa si no califiqué?**  
¡No te desanimes! El sistema también te muestra opciones similares con el botón **"Ver otras opciones"**. Además, un puntaje menor significa que con algo de preparación puedes lograrlo.

**¿Puedo hacer el test varias veces?**  
Sí. Haz clic en **"🔄 Hacer otro test"** al final de los resultados para empezar de nuevo.

**¿Puedo cancelar si me equivoqué?**  
Sí. En cualquier momento durante el cuestionario hay un botón **"✖ Cancelar"** que te pedirá confirmar antes de borrar todo.

**¿Mis datos están seguros?**  
Tu contraseña se guarda cifrada. Solo tú puedes acceder a tu cuenta.

**¿En qué ciudades funciona?**  
Actualmente tiene datos de universidades y empresas en Bogotá, Medellín, Cali, Barranquilla, Bucaramanga, Pereira y Pasto. Si tu ciudad no aparece, se mostrarán las opciones más cercanas disponibles.

---

## ¿Qué significan los colores de los botones?

| Color | Botón | Significado |
|-------|-------|-------------|
| 🔵 Azul | ESTUDIO | Camino hacia carrera universitaria |
| 🟢 Verde | TRABAJO | Camino hacia empleo directo |
| 🟣 Morado | Acciones principales | Continuar, Iniciar, Ver resultados |
| 🔴 Rojo | Cancelar, errores | Acciones de atención o alertas |

---

## Soporte

Si encuentras algún problema técnico, recarga la página (F5) y vuelve a intentarlo. Tu progreso se guarda automáticamente en cada respuesta.
